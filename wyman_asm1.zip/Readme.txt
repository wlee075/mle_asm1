https://github.com/wlee075/mle_asm1/tree/data_cleaning
